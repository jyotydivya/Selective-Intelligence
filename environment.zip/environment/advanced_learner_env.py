import numpy as np
import random


class AdvancedLearnerEnv:

    def __init__(self, learner_type=None):

        # ---------------------------------------------------
        # Learner Type
        # ---------------------------------------------------
        # 0 = Beginner
        # 1 = Intermediate
        # 2 = Advanced
        if learner_type is None:
            self.learner_type = np.random.choice([0, 1, 2])
        else:
            self.learner_type = learner_type

        # ---------------------------------------------------
        # Cognitive State Variables
        # ---------------------------------------------------
        self.skill_level = 0           # 0–3
        self.performance = 1           # 0–2
        self.frustration = 1           # 0–2
        self.help_dependency = 1       # 0–2
        self.difficulty = 0            # 0–3

        # internal memory
        self.recent_correct = 0


    # ---------------------------------------------------
    # State Representation
    # ---------------------------------------------------
    def get_state(self):

        return (
            self.learner_type,
            self.skill_level,
            self.performance,
            self.frustration,
            self.help_dependency,
            self.difficulty
        )


    # ---------------------------------------------------
    # Success Probability Model
    # ---------------------------------------------------
    def compute_success_probability(self, action):

        # Skill vs difficulty alignment
        gap = self.skill_level - self.difficulty

        base_prob = 0.45 + 0.15 * gap

        # Emotional influence
        frustration_effect = {
            0: +0.10,
            1: 0.0,
            2: -0.15
        }

        # Short-term performance influence
        performance_effect = {
            0: -0.10,
            1: 0.0,
            2: +0.10
        }

        # Help dependency influence
        help_effect = {
            0: +0.05,
            1: 0.0,
            2: -0.10
        }

        # Intervention effects
        # 0 Pause
        # 1 Hint
        # 2 Socratic
        # 3 Explanation
        action_effect = [0.0, 0.10, 0.05, 0.25]

        prob = base_prob
        prob += frustration_effect[self.frustration]
        prob += performance_effect[self.performance]
        prob += help_effect[self.help_dependency]
        prob += action_effect[action]

        return np.clip(prob, 0.05, 0.95)


    # ---------------------------------------------------
    # Step Function
    # ---------------------------------------------------
    def step(self, action):

        prob = self.compute_success_probability(action)
        success = np.random.rand() < prob

        # ---------------------------------------------------
        # Reward Design
        # ---------------------------------------------------
        if success:
            if action == 0:
                reward = 15      # pause
            elif action == 1:
                reward = 10      # hint
            elif action == 2:
                reward = 7       # socratic
            else:
                reward = 3       # explanation
        else:
            reward = -5
            if action == 3:
                reward -= 5


        # ---------------------------------------------------
        # Skill Evolution
        # ---------------------------------------------------
        if success and random.random() < 0.30:
            self.skill_level = min(3, self.skill_level + 1)


        # ---------------------------------------------------
        # Performance Update
        # ---------------------------------------------------
        if success:
            self.recent_correct += 1
        else:
            self.recent_correct -= 1

        self.recent_correct = np.clip(self.recent_correct, -3, 3)

        if self.recent_correct >= 2:
            self.performance = min(2, self.performance + 1)

        if self.recent_correct <= -2:
            self.performance = max(0, self.performance - 1)


        # ---------------------------------------------------
        # Frustration Dynamics
        # ---------------------------------------------------
        if success:
            self.frustration = max(0, self.frustration - 1)
        else:
            if action != 3:
                self.frustration = min(2, self.frustration + 1)


        # ---------------------------------------------------
        # Help Dependency Dynamics
        # ---------------------------------------------------
        if action == 3:
            self.help_dependency = min(2, self.help_dependency + 1)
        else:
            if success:
                self.help_dependency = max(0, self.help_dependency - 1)


        # ---------------------------------------------------
        # Difficulty Scheduling
        # ---------------------------------------------------
        if success and random.random() < 0.25:
            self.difficulty = min(3, self.difficulty + 1)

        if not success and random.random() < 0.20:
            self.difficulty = max(0, self.difficulty - 1)


        next_state = self.get_state()

        return next_state, reward, success