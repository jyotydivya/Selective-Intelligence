import numpy as np
import random

class QLearningAgent:
    def __init__(self, num_states=(3,3,3,3), num_actions=4, alpha=0.1, gamma=0.9, epsilon=0.2):
        self.Q = np.zeros(num_states + (num_actions,))
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.num_actions = num_actions

    def choose_action(self, state):
        if random.random() < self.epsilon:
            return random.randint(0, self.num_actions - 1)
        return np.argmax(self.Q[state])

    def update(self, state, action, reward, next_state):
        best_next = np.max(self.Q[next_state])
        self.Q[state][action] += self.alpha * (reward + self.gamma * best_next - self.Q[state][action])