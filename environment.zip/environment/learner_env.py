import random
import numpy as np

class LearnerEnv:
    def __init__(self):
        # State variables (discrete: 0=Low, 1=Medium, 2=High)
        self.performance = random.randint(0, 2)
        self.help_dep = random.randint(0, 2)
        self.difficulty = random.randint(0, 2)
        self.frustration = random.randint(0, 2)

    def get_state(self):
        return (self.performance, self.help_dep, self.difficulty, self.frustration)

    def step(self, action):
        """
        Actions:
        0 = Productive Pause
        1 = Hint
        2 = Socratic Question
        3 = Full Explanation
        """

        # success probability base
        base_success = [0.3, 0.6, 0.85][self.performance]

        # difficulty adjustment
        diff_adj = [0.15, 0.0, -0.15][self.difficulty]

        # action benefit
        action_boost = [0.0, 0.20, 0.10, 0.40][action]

        success_prob = base_success + diff_adj + action_boost
        success_prob = np.clip(success_prob, 0.05, 0.95)

        success = random.random() < success_prob

        # Reward Logic
        if success and action == 0:
            reward = 12
        elif success and action == 1:
            reward = 8
        elif success and action == 2:
            reward = 6
        elif success and action == 3:
            reward = 3
        elif not success and action == 3:
            reward = -6
        else:
            reward = -2  # mild penalty for unproductive attempts

        # Update frustration
        if success:
            self.frustration = max(0, self.frustration - 1)
        else:
            self.frustration = min(2, self.frustration + 1)

        # Update performance randomly (simulation)
        if success:
            self.performance = min(2, self.performance + 1)
        else:
            self.performance = max(0, self.performance - 1)

        # Update help dependency
        if action == 3:
            self.help_dep = min(2, self.help_dep + 1)
        elif action == 0:
            self.help_dep = max(0, self.help_dep - 1)

        next_state = self.get_state()
        return next_state, reward, success