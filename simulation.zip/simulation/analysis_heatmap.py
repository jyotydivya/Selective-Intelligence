import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

RESULTS_DIR = "results_advanced"

def load_actions(file):
    return np.load(file, allow_pickle=True)


def plot_action_heatmap(action_log, bin_size=100):

    total_actions = len(action_log)

    # If each episode has ~50 steps:
    estimated_episodes = total_actions // 50

    # Compute number of bins correctly
    num_bins = estimated_episodes // bin_size

    heatmap = np.zeros((4, num_bins))

    step_counter = 0
    episode = 0

    for action in action_log:

        # Every 50 steps = 1 episode
        if step_counter % 50 == 0 and step_counter != 0:
            episode += 1

        if episode < num_bins:
            bin_index = episode // bin_size
            if bin_index < num_bins:
                heatmap[action][bin_index] += 1

        step_counter += 1

    plt.figure(figsize=(14, 4))
    sns.heatmap(
        heatmap,
        cmap="cool",
        xticklabels=[f"{i*bin_size}-{(i+1)*bin_size}" for i in range(num_bins)],
        yticklabels=["Pause", "Hint", "Socratic", "Explain"]
    )

    plt.title("Action Distribution Heatmap (Adaptive Binning)")
    plt.xlabel("Episode Range")
    plt.ylabel("Action Type")

    plt.savefig(os.path.join(RESULTS_DIR, "action_heatmap.png"))
    plt.close()



if __name__ == "__main__":
    action_log = load_actions(os.path.join(RESULTS_DIR, "actions.npy"))
    plot_action_heatmap(action_log)